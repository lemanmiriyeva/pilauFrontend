"use client"
import React from 'react';
import {ThemeProvider} from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import {muiTheme} from '@/components/theme/muiTheme';

export default function ThemeRegistry({children}) {
    return (
        <ThemeProvider theme={muiTheme}>
            <CssBaseline/>
            {children}
        </ThemeProvider>
    );
}