'use server'

import {cookies} from "next/headers";
import {get_request} from "@/app/api/utils";
import {DJANGO_API_ENDPOINTS} from "@/app/urls";
import {handleError} from "@/app/utils";

export async function GET(req, {params}) {
    try {
        const {id} = await params;

        const cookieStore = await cookies();

        const access = cookieStore.get("access");
        const refresh = cookieStore.get("refresh");

        const res = await get_request(
            DJANGO_API_ENDPOINTS.ORGANIZATIONS.DEPARTMENTS(id),
            access,
            refresh
        );

        const data = await res.json();

        return Response.json(data, {
            status: res.status,
        });

    } catch (e) {
        console.error("Departments API error:", e);

        return Response.json(
            {detail: handleError(e)},
            {status: 500}
        );
    }
}